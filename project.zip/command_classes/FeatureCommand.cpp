#include "FeatureCommand.h"

void FeatureCommand::execute(Game *game, ostream &logFile) {

}